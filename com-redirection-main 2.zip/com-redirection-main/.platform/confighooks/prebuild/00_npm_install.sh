#!/bin/bash
cd /var/app/staging
sudo -u webapp npm install sharp