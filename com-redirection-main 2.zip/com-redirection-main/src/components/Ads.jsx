import React, { Component } from 'react';

class Ads extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (  <>
        <div>
            <p>google.com, pub-5645705217995911, DIRECT, f08c47fec0942fa0</p>
        </div>
        </>);
    }
}
 
export default Ads;