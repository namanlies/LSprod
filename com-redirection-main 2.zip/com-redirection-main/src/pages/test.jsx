import React, { Component } from 'react';

class Testpage extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (  <>
            <h1>Hi, I am a test page.</h1>
        </>);
    }
}
 
export default Testpage;